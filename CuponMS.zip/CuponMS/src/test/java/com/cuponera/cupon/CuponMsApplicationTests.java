package com.cuponera.cupon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuponMsApplicationTests {

	@Test
	void contextLoads() {
	}

}

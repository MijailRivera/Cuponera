package com.cuponera.cupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuponMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuponMsApplication.class, args);
	}

}

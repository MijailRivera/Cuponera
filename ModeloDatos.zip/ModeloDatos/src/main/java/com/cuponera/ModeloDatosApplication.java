package com.cuponera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModeloDatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModeloDatosApplication.class, args);
	}

}
